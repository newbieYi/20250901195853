export enum ReviewMethodType {
  KISS = 'KISS',
  GRAI = 'GRAI',
  DEEP_DIVE = 'DEEP_DIVE'
}

export interface ReviewEntry {
  id: string;
  date: number; // Timestamp
  title: string;
  method: ReviewMethodType;
  content: any; // Flexible payload based on method
  tags?: string[];
}

// KISS Data Structure
export interface KissData {
  keep: string;
  improve: string;
  stop: string;
  start: string;
}

// GRAI Data Structure
export interface GraiData {
  goal: string;
  result: string;
  analysis: string;
  insight: string;
}

// Deep Dive Data Structure
export interface DeepDiveData {
  step1_review: string; // Review Goal
  step2_analyze: string; // Root Cause
  step3_extract: string; // Extract Learnings
  step4_action: string; // Action Plan
}

export interface RecommendationResult {
  recommendedMethod: ReviewMethodType;
  reason: string;
}

export enum ReportType {
  DAILY = 'DAILY',
  YEARLY = 'YEARLY'
}