import { GoogleGenAI, Type } from "@google/genai";
import { ReviewMethodType, RecommendationResult, ReviewEntry, ReportType } from "../types";
import { format } from 'date-fns';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// System instructions for the general assistant
const SYSTEM_INSTRUCTION = "You are an expert agile coach and business analyst helping users conduct professional retrospectives (复盘).";

export const getMethodRecommendation = async (userContext: string): Promise<RecommendationResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `User scenario: "${userContext}".
      
      I have three review (复盘) methodologies:
      1. KISS (Keep, Improve, Stop, Start): Agile, quick, action-oriented.
      2. GRAI (Goal, Result, Analysis, Insight): Data-driven, gap analysis, project performance.
      3. DEEP_DIVE (Review, Analyze, Extract, Apply): Strategic, root cause analysis, complex failures/milestones.
      
      Analyze the user's scenario and recommend the ONE best method.`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendedMethod: {
              type: Type.STRING,
              enum: [ReviewMethodType.KISS, ReviewMethodType.GRAI, ReviewMethodType.DEEP_DIVE]
            },
            reason: {
              type: Type.STRING,
              description: "A professional, convincing reason in Chinese (max 30 words) why this method is the perfect fit."
            }
          },
          required: ["recommendedMethod", "reason"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as RecommendationResult;
    }
    
    throw new Error("No response from AI");
  } catch (error) {
    console.error("Error getting recommendation:", error);
    return {
      recommendedMethod: ReviewMethodType.KISS,
      reason: "KISS复盘法通用性强，适合大多数场景，建议您尝试。"
    };
  }
};

export enum RefineAction {
  EXPAND = "EXPAND",
  POLISH = "POLISH",
  SUMMARIZE = "SUMMARIZE",
  ACTION_ITEMS = "ACTION_ITEMS"
}

export const refineText = async (text: string, action: RefineAction, context: string = ""): Promise<string> => {
  if (!text) return "";
  
  let prompt = "";
  switch (action) {
    case RefineAction.EXPAND:
      prompt = "Expand on the following thought, adding more detail and depth suitable for a professional review. Keep it in Chinese.";
      break;
    case RefineAction.POLISH:
      prompt = "Polish the following text to make it professional, concise, and clear. Keep it in Chinese.";
      break;
    case RefineAction.SUMMARIZE:
      prompt = "Summarize the following text into a key insight or bullet point. Keep it in Chinese.";
      break;
    case RefineAction.ACTION_ITEMS:
      prompt = "Extract concrete, actionable steps from the following reflection. Format as a bulleted list. Keep it in Chinese.";
      break;
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `${prompt}\n\nContext: ${context}\n\nInput Text: "${text}"`,
      config: {
         systemInstruction: SYSTEM_INSTRUCTION,
      }
    });
    return response.text || text;
  } catch (error) {
    console.error("AI Refine Error", error);
    return text; // Fail gracefully by returning original text
  }
}

export const generateReport = async (reviews: ReviewEntry[], type: ReportType): Promise<string> => {
  if (reviews.length === 0) return "";

  const reviewsContent = reviews.map(r => `
    Title: ${r.title}
    Date: ${format(r.date, 'yyyy-MM-dd')}
    Method: ${r.method}
    Content: ${JSON.stringify(r.content)}
  `).join('\n---\n');

  let prompt = "";
  if (type === ReportType.DAILY) {
    prompt = `Generate a professional 'Daily Report' (日常汇报) for a team leader based on the following reviews. 
    Focus on progress, blockers, and key achievements. 
    Format using Markdown with sections: 
    1. 💡 Key Achievements (今日亮点)
    2. 🚧 Blockers & Issues (问题与阻碍)
    3. 📅 Next Steps (明日计划)
    Keep the tone professional and concise. Output in Chinese.`;
  } else {
    prompt = `Generate a comprehensive 'Year-End Summary' (年终总结) based on the following reviews.
    Analyze trends, major wins, and growth areas.
    Format using Markdown with sections:
    1. 🏆 Major Milestones (年度里程碑)
    2. 📈 Key Learnings & Growth (成长与收获)
    3. 🧩 Areas for Improvement (不足与改进)
    4. 🎯 Outlook for Next Year (展望未来)
    Keep the tone inspiring and professional. Output in Chinese.`;
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Task: ${prompt}\n\nReviews Data:\n${reviewsContent}`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      }
    });
    return response.text || "生成报告失败，请重试。";
  } catch (error) {
    console.error("Report Generation Error", error);
    return "生成报告时发生错误，请检查网络或重试。";
  }
};