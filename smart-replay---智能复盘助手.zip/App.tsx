
import React, { useState, useEffect } from 'react';
import { ReviewMethodType, ReviewEntry, KissData, GraiData, DeepDiveData, RecommendationResult, ReportType } from './types';
import { getMethodRecommendation, generateReport } from './services/geminiService';
import { KissEditor, GraiEditor, DeepDiveEditor } from './components/Worksheets';
import { SparklesIcon, PlusIcon, ArrowLeftIcon, SaveIcon, TrashIcon, ChevronRightIcon, HomeIcon, LayoutIcon, LoadingIcon, FileTextIcon, CheckIcon, XIcon, CopyIcon } from './components/Icons';
import { format } from 'date-fns';

// --- Default States ---
const initialKiss: KissData = { keep: '', improve: '', stop: '', start: '' };
const initialGrai: GraiData = { goal: '', result: '', analysis: '', insight: '' };
const initialDeep: DeepDiveData = { step1_review: '', step2_analyze: '', step3_extract: '', step4_action: '' };

// --- Sub-Components (Defined outside App to prevent re-renders) ---

const Sidebar = ({ 
  view, 
  setView, 
  history, 
  onDeleteHistory, 
  onOpenHistory, 
  onReset 
}: { 
  view: string; 
  setView: (v: any) => void; 
  history: ReviewEntry[]; 
  onDeleteHistory: (id: string, e: React.MouseEvent) => void; 
  onOpenHistory: (item: ReviewEntry) => void;
  onReset: () => void;
}) => (
  <div className="w-64 bg-white h-screen border-r border-gray-100 flex flex-col shadow-[4px_0_24px_rgba(0,0,0,0.02)] z-20 shrink-0">
    <div className="p-6">
      <div className="flex items-center gap-2 mb-8 cursor-pointer" onClick={() => setView('home')}>
         <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-indigo-200">
           <LayoutIcon className="w-5 h-5" />
         </div>
         <h1 className="font-black text-xl text-gray-800 tracking-tight">SmartReplay</h1>
      </div>

      <button 
        onClick={onReset}
        className="w-full bg-indigo-600 text-white p-3 rounded-xl shadow-lg shadow-indigo-200 hover:shadow-xl hover:bg-indigo-700 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2 font-bold text-sm mb-6 group"
      >
        <PlusIcon className="w-4 h-4 transition-transform group-hover:rotate-90" />
        开始新复盘
      </button>

      <nav className="space-y-1">
         <button 
           onClick={() => setView('home')} 
           className={`w-full flex items-center gap-3 p-3 rounded-xl text-sm font-medium transition-colors ${view === 'home' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'}`}
         >
            <HomeIcon className="w-4 h-4" />
            我的复盘库
         </button>
      </nav>
    </div>

    <div className="flex-1 overflow-y-auto px-4 pb-4 custom-scrollbar">
       <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3 px-2">最近记录</div>
       <div className="space-y-1">
          {history.length === 0 && (
            <div className="px-2 text-sm text-gray-400 italic">暂无记录</div>
          )}
          {history.map(item => (
            <div 
              key={item.id}
              onClick={() => onOpenHistory(item)}
              className="group relative flex items-center gap-3 p-3 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 cursor-pointer transition-colors"
            >
               <div className={`w-2 h-2 rounded-full shrink-0 ${
                 item.method === 'KISS' ? 'bg-lime-400' : 
                 item.method === 'GRAI' ? 'bg-sky-400' : 'bg-indigo-400'
               }`} />
               <span className="truncate flex-1">{item.title}</span>
               <button 
                 onClick={(e) => onDeleteHistory(item.id, e)}
                 className="opacity-0 group-hover:opacity-100 p-1 hover:bg-red-100 hover:text-red-600 rounded transition-opacity"
                 title="删除"
               >
                 <TrashIcon className="w-3 h-3" />
               </button>
            </div>
          ))}
       </div>
    </div>
    
    <div className="p-4 border-t border-gray-100">
       <div className="flex items-center gap-3 p-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white font-bold text-xs">
            U
          </div>
          <div className="text-sm">
             <div className="font-bold text-gray-700">User</div>
             <div className="text-xs text-gray-400">Pro Plan</div>
          </div>
       </div>
    </div>
  </div>
);

const HomeView = ({ 
  history, 
  setView, 
  onOpenHistory, 
  selectedIds, 
  toggleSelection, 
  generateReportHandler 
}: any) => {
  const isSelectionMode = selectedIds.length > 0;

  return (
    <div className="max-w-5xl mx-auto w-full pb-20">
       <header className="mb-10 flex justify-between items-end">
         <div>
           <h2 className="text-3xl font-black text-gray-800 mb-2">欢迎回来</h2>
           <p className="text-gray-500">所有的成功都源于对经验的深度复盘。</p>
         </div>
       </header>
  
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="bg-white p-6 rounded-2xl shadow-[0_2px_20px_rgba(0,0,0,0.04)] border border-gray-100">
             <div className="text-4xl font-black text-gray-800 mb-2">{history.length}</div>
             <div className="text-gray-500 text-sm font-medium">累计复盘次数</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-[0_2px_20px_rgba(0,0,0,0.04)] border border-gray-100">
             <div className="text-4xl font-black text-lime-600 mb-2">
               {history.filter((h: any) => h.method === 'KISS').length}
             </div>
             <div className="text-gray-500 text-sm font-medium">KISS 快速复盘</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-[0_2px_20px_rgba(0,0,0,0.04)] border border-gray-100">
             <div className="text-4xl font-black text-sky-600 mb-2">
               {history.filter((h: any) => h.method === 'GRAI').length}
             </div>
             <div className="text-gray-500 text-sm font-medium">GRAI 复盘法</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-[0_2px_20px_rgba(0,0,0,0.04)] border border-gray-100">
             <div className="text-4xl font-black text-indigo-600 mb-2">
               {history.filter((h: any) => h.method === 'DEEP_DIVE').length}
             </div>
             <div className="text-gray-500 text-sm font-medium">Deep Dive 深度复盘</div>
          </div>
       </div>
  
       <h3 className="text-xl font-bold text-gray-800 mb-6 flex justify-between items-center">
         最近复盘
         <span className="text-xs text-gray-400 font-normal">
            {isSelectionMode ? `已选择 ${selectedIds.length} 项` : "点击卡片查看，长按或点击复选框多选"}
         </span>
       </h3>

       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {history.length === 0 ? (
            <div onClick={() => setView('recommend')} className="border-2 border-dashed border-gray-200 rounded-2xl p-8 flex flex-col items-center justify-center text-gray-400 hover:border-indigo-300 hover:bg-indigo-50/50 transition-all cursor-pointer h-48 group">
               <PlusIcon className="w-8 h-8 mb-2 group-hover:scale-110 transition-transform text-indigo-300" />
               <span>开始第一次复盘</span>
            </div>
          ) : (
            history.map((item: any) => {
              const isSelected = selectedIds.includes(item.id);
              return (
                <div 
                  key={item.id} 
                  className={`bg-white group rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border transition-all duration-300 cursor-pointer flex flex-col relative
                    ${isSelected ? 'ring-2 ring-indigo-500 border-indigo-500 transform scale-[1.02]' : 'border-gray-100 hover:-translate-y-1'}
                  `}
                  onClick={() => {
                     if(isSelectionMode) toggleSelection(item.id);
                     else onOpenHistory(item);
                  }}
                >
                  <div className={`h-2 w-full ${
                     item.method === 'KISS' ? 'bg-gradient-to-r from-lime-400 to-green-500' : 
                     item.method === 'GRAI' ? 'bg-gradient-to-r from-sky-400 to-blue-500' : 
                     'bg-gradient-to-r from-indigo-500 to-purple-600'
                  }`} />
                  <div className="p-6 flex-1 flex flex-col">
                     <div className="flex justify-between items-start mb-4">
                        <span className={`px-2 py-1 rounded-md text-xs font-bold uppercase tracking-wide ${
                          item.method === 'KISS' ? 'bg-lime-100 text-lime-700' : 
                          item.method === 'GRAI' ? 'bg-sky-100 text-sky-700' : 
                          'bg-indigo-100 text-indigo-700'
                        }`}>
                          {item.method.replace('_', ' ')}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-gray-400">{format(item.date, 'MM月dd日')}</span>
                          {/* Checkbox for selection */}
                          <div 
                             onClick={(e) => { e.stopPropagation(); toggleSelection(item.id); }}
                             className={`w-5 h-5 rounded border flex items-center justify-center transition-colors
                               ${isSelected ? 'bg-indigo-600 border-indigo-600' : 'border-gray-300 hover:border-indigo-400 bg-white'}
                             `}
                          >
                             {isSelected && <CheckIcon className="w-3 h-3 text-white" />}
                          </div>
                        </div>
                     </div>
                     <h4 className="font-bold text-lg text-gray-800 mb-2 line-clamp-2">{item.title}</h4>
                     <p className="text-sm text-gray-500 line-clamp-3 mb-4 flex-1">
                        {item.method === 'KISS' ? (item.content as KissData).keep || '无内容' : 
                         item.method === 'GRAI' ? (item.content as GraiData).goal || '无内容' : 
                         (item.content as DeepDiveData).step1_review || '无内容'}
                     </p>
                  </div>
                </div>
              );
            })
          )}
       </div>

       {/* Floating Action Bar for Reports */}
       {isSelectionMode && (
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-gray-900 text-white pl-6 pr-2 py-2 rounded-full shadow-2xl z-50 flex items-center gap-6 animate-in">
             <span className="font-bold text-sm whitespace-nowrap">已选择 {selectedIds.length} 个复盘</span>
             <div className="flex gap-2">
                <button 
                  onClick={() => generateReportHandler(ReportType.DAILY)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-full text-xs font-bold transition-colors flex items-center gap-1"
                >
                  <FileTextIcon className="w-3 h-3" /> 生成日常汇报
                </button>
                <button 
                   onClick={() => generateReportHandler(ReportType.YEARLY)}
                   className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-full text-xs font-bold transition-colors flex items-center gap-1"
                >
                  <SparklesIcon className="w-3 h-3" /> 生成年终总结
                </button>
                <button 
                  onClick={() => toggleSelection('CLEAR_ALL')} 
                  className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/20 text-gray-400 hover:text-white transition-colors ml-2"
                >
                  <XIcon className="w-4 h-4" />
                </button>
             </div>
          </div>
       )}
    </div>
  );
};

const RecommendView = ({ userContext, setUserContext, isAnalyzing, handleStartAnalysis, setView }: any) => (
  <div className="max-w-2xl mx-auto w-full pt-10">
    <div className="text-center mb-10">
      <div className="w-16 h-16 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600 mx-auto mb-6">
         <SparklesIcon className="w-8 h-8" />
      </div>
      <h2 className="text-3xl font-black text-gray-800 mb-3">开启智能复盘之旅</h2>
      <p className="text-gray-500 text-lg">简单描述您想复盘的事情（项目、事件、周期），AI将为您推荐最适合的方法论。</p>
    </div>

    <div className="bg-white p-2 rounded-3xl shadow-[0_8px_30px_rgba(0,0,0,0.06)] border border-gray-100">
       <textarea 
         value={userContext} 
         onChange={e => setUserContext(e.target.value)}
         className="w-full h-40 p-6 rounded-2xl resize-none focus:outline-none bg-slate-50 border border-slate-200 text-slate-900 text-lg placeholder:text-gray-400"
         placeholder="例如：我们刚结束了一个为期两周的营销活动，效果一般，团队配合有些混乱..."
       />
       <div className="flex justify-between items-center px-4 pb-4 mt-2">
          <button 
            onClick={() => setView('select')}
            className="text-gray-400 hover:text-gray-600 text-sm font-medium px-4 py-2"
          >
            跳过，直接选模版
          </button>
          <button 
            onClick={handleStartAnalysis}
            disabled={!userContext.trim() || isAnalyzing}
            className={`bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold text-lg shadow-lg shadow-indigo-200 transition-all flex items-center gap-2
              ${(!userContext.trim() || isAnalyzing) ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105 hover:bg-indigo-700'}
            `}
          >
            {isAnalyzing ? (
              <><LoadingIcon className="w-5 h-5 animate-spin" /> 分析中...</>
            ) : (
              <><SparklesIcon className="w-5 h-5" /> 智能推荐</>
            )}
          </button>
       </div>
    </div>
  </div>
);

const SelectView = ({ setView, recommendation, handleSelectMethod }: any) => (
  <div className="max-w-6xl mx-auto w-full pt-4">
    <div className="flex items-center gap-4 mb-8">
      <button onClick={() => setView('recommend')} className="p-2 hover:bg-white rounded-full transition-colors text-gray-500">
        <ArrowLeftIcon className="w-6 h-6" />
      </button>
      <div>
         <h2 className="text-2xl font-black text-gray-800">选择复盘卡片</h2>
         {recommendation && (
           <p className="text-indigo-600 font-medium mt-1 flex items-center gap-2">
             <SparklesIcon className="w-4 h-4" /> 
             AI 推荐：{recommendation.reason}
           </p>
         )}
      </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4 perspective-1000">
       {/* KISS Card */}
       <div 
         onClick={() => handleSelectMethod(ReviewMethodType.KISS)}
         className={`relative group cursor-pointer animate-deal delay-100 ${recommendation?.recommendedMethod === ReviewMethodType.KISS ? 'ring-4 ring-indigo-400 ring-offset-4' : ''}`}
       >
          <div className="bg-white rounded-[2rem] overflow-hidden shadow-[0_10px_40px_-10px_rgba(0,0,0,0.1)] hover:shadow-[0_20px_50px_-10px_rgba(0,0,0,0.2)] transition-all duration-300 transform group-hover:-translate-y-2 h-[500px] flex flex-col border border-gray-100">
             <div className="h-48 bg-lime-100/50 relative overflow-hidden p-6 flex items-center justify-center">
                <div className="absolute inset-0 bg-[radial-gradient(#a3e635_1px,transparent_1px)] [background-size:16px_16px] opacity-30"></div>
                <div className="text-8xl font-black text-lime-500/20 absolute -right-4 -bottom-8 rotate-12">KISS</div>
                <div className="grid grid-cols-2 gap-2 w-32 h-32 rotate-3">
                   <div className="bg-lime-400 rounded-lg"></div>
                   <div className="bg-sky-400 rounded-lg"></div>
                   <div className="bg-amber-400 rounded-lg"></div>
                   <div className="bg-rose-400 rounded-lg"></div>
                </div>
             </div>
             <div className="p-8 flex-1 flex flex-col relative">
                {recommendation?.recommendedMethod === ReviewMethodType.KISS && (
                   <div className="absolute top-0 right-0 bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-bl-xl">推荐</div>
                )}
                <h3 className="text-2xl font-black text-gray-800 mb-2">KISS 复盘法</h3>
                <p className="text-gray-500 text-sm mb-6 leading-relaxed">
                   Keep / Improve / Stop / Start
                   <br/>
                   最轻量的敏捷复盘工具。
                </p>
                <ul className="space-y-3 mb-8 text-sm text-gray-600">
                   <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-lime-500"/> 快速迭代的项目</li>
                   <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-lime-500"/> 日常/周度回顾</li>
                   <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-lime-500"/> 团队氛围改进</li>
                </ul>
                <button className="mt-auto w-full py-3 rounded-xl border-2 border-lime-100 text-lime-700 font-bold hover:bg-lime-50 transition-colors">选择此卡片</button>
             </div>
          </div>
       </div>

       {/* GRAI Card */}
       <div 
         onClick={() => handleSelectMethod(ReviewMethodType.GRAI)}
         className={`relative group cursor-pointer animate-deal delay-200 ${recommendation?.recommendedMethod === ReviewMethodType.GRAI ? 'ring-4 ring-indigo-400 ring-offset-4' : ''}`}
       >
          <div className="bg-white rounded-[2rem] overflow-hidden shadow-[0_10px_40px_-10px_rgba(0,0,0,0.1)] hover:shadow-[0_20px_50px_-10px_rgba(0,0,0,0.2)] transition-all duration-300 transform group-hover:-translate-y-2 h-[500px] flex flex-col border border-gray-100">
             <div className="h-48 bg-sky-100/50 relative overflow-hidden p-6 flex items-center justify-center">
                <div className="absolute inset-0 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px] opacity-30"></div>
                <div className="text-8xl font-black text-sky-500/20 absolute -left-4 -top-4 -rotate-12">GRAI</div>
                <div className="flex gap-1 items-end h-24 w-32 justify-center">
                   <div className="w-4 bg-sky-300 h-1/3 rounded-t"></div>
                   <div className="w-4 bg-sky-400 h-2/3 rounded-t"></div>
                   <div className="w-4 bg-sky-500 h-full rounded-t"></div>
                   <div className="w-4 bg-sky-600 h-1/2 rounded-t"></div>
                </div>
             </div>
             <div className="p-8 flex-1 flex flex-col relative">
                {recommendation?.recommendedMethod === ReviewMethodType.GRAI && (
                   <div className="absolute top-0 right-0 bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-bl-xl">推荐</div>
                )}
                <h3 className="text-2xl font-black text-gray-800 mb-2">GRAI 复盘法</h3>
                <p className="text-gray-500 text-sm mb-6 leading-relaxed">
                   Goal / Result / Analysis / Insight
                   <br/>
                   经典的结构化复盘模型。
                </p>
                <ul className="space-y-3 mb-8 text-sm text-gray-600">
                   <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-sky-500"/> 项目阶段性总结</li>
                   <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-sky-500"/> 绩效/目标达成分析</li>
                   <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-sky-500"/> 寻找差距与原因</li>
                </ul>
                <button className="mt-auto w-full py-3 rounded-xl border-2 border-sky-100 text-sky-700 font-bold hover:bg-sky-50 transition-colors">选择此卡片</button>
             </div>
          </div>
       </div>

       {/* Deep Dive Card */}
       <div 
         onClick={() => handleSelectMethod(ReviewMethodType.DEEP_DIVE)}
         className={`relative group cursor-pointer animate-deal delay-300 ${recommendation?.recommendedMethod === ReviewMethodType.DEEP_DIVE ? 'ring-4 ring-indigo-400 ring-offset-4' : ''}`}
       >
          <div className="bg-white rounded-[2rem] overflow-hidden shadow-[0_10px_40px_-10px_rgba(0,0,0,0.1)] hover:shadow-[0_20px_50px_-10px_rgba(0,0,0,0.2)] transition-all duration-300 transform group-hover:-translate-y-2 h-[500px] flex flex-col border border-gray-100">
             <div className="h-48 bg-indigo-900 relative overflow-hidden p-6 flex items-center justify-center">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-30"></div>
                <div className="w-32 h-32 border-4 border-indigo-400/30 rounded-full flex items-center justify-center relative">
                   <div className="w-20 h-20 border-4 border-indigo-400/50 rounded-full flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                   </div>
                </div>
             </div>
             <div className="p-8 flex-1 flex flex-col relative">
                {recommendation?.recommendedMethod === ReviewMethodType.DEEP_DIVE && (
                   <div className="absolute top-0 right-0 bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-bl-xl">推荐</div>
                )}
                <h3 className="text-2xl font-black text-gray-800 mb-2">Deep Dive</h3>
                <p className="text-gray-500 text-sm mb-6 leading-relaxed">
                   Review / Analyze / Extract / Apply
                   <br/>
                   深度根因分析与经验萃取。
                </p>
                <ul className="space-y-3 mb-8 text-sm text-gray-600">
                   <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-indigo-900"/> 重大事故/成功复盘</li>
                   <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-indigo-900"/> 复杂问题的根因探索</li>
                   <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-indigo-900"/> 建立组织知识库</li>
                </ul>
                <button className="mt-auto w-full py-3 rounded-xl border-2 border-indigo-100 text-indigo-900 font-bold hover:bg-indigo-50 transition-colors">选择此卡片</button>
             </div>
          </div>
       </div>
    </div>
  </div>
);

const EditorView = ({ 
  setView, 
  editorTitle, 
  setEditorTitle, 
  handleSave, 
  activeMethod, 
  kissData, 
  setKissData, 
  graiData, 
  setGraiData, 
  deepData, 
  setDeepData 
}: any) => (
  <div className="flex flex-col h-full w-full max-w-6xl mx-auto">
     <div className="flex items-center justify-between mb-6 shrink-0">
        <div className="flex items-center gap-4">
           <button onClick={() => setView('home')} className="p-2 hover:bg-white rounded-full transition-colors text-gray-500">
             <ArrowLeftIcon className="w-6 h-6" />
           </button>
           <div className="flex flex-col">
             <label className="text-xs text-gray-400 font-bold ml-2">复盘标题</label>
             <input 
               type="text" 
               value={editorTitle} 
               onChange={(e) => setEditorTitle(e.target.value)}
               className="text-2xl font-bold bg-transparent border-b-2 border-transparent hover:border-gray-200 focus:border-indigo-500 focus:bg-white/50 rounded px-2 py-1 text-gray-800 placeholder-gray-400 w-[400px] focus:outline-none transition-all"
               placeholder="输入复盘标题..."
               autoFocus
             />
           </div>
        </div>
        <div className="flex gap-3">
           <button 
             onClick={handleSave}
             className="bg-gray-900 text-white px-6 py-2 rounded-xl font-bold shadow-lg hover:bg-black transition-colors flex items-center gap-2"
           >
             <SaveIcon className="w-4 h-4" />
             保存复盘
           </button>
        </div>
     </div>

     <div className="flex-1 min-h-0 pb-6">
        {activeMethod === ReviewMethodType.KISS && <KissEditor data={kissData} onChange={setKissData} />}
        {activeMethod === ReviewMethodType.GRAI && <GraiEditor data={graiData} onChange={setGraiData} />}
        {activeMethod === ReviewMethodType.DEEP_DIVE && <DeepDiveEditor data={deepData} onChange={setDeepData} />}
     </div>
  </div>
);

const ReportModal = ({ content, onClose }: { content: string, onClose: () => void }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
       <div className="bg-white rounded-3xl w-full max-w-3xl h-[80vh] flex flex-col shadow-2xl animate-deal">
          <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-3xl">
             <div className="flex items-center gap-3">
               <div className="bg-indigo-600 text-white p-2 rounded-lg">
                 <FileTextIcon className="w-5 h-5" />
               </div>
               <div>
                  <h3 className="font-bold text-gray-800 text-lg">AI 生成报告</h3>
                  <p className="text-xs text-gray-500">基于所选复盘内容生成</p>
               </div>
             </div>
             <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full text-gray-500 transition-colors">
               <XIcon className="w-5 h-5" />
             </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
             <div className="prose prose-indigo max-w-none whitespace-pre-wrap text-gray-700 leading-relaxed">
               {content}
             </div>
          </div>
          
          <div className="p-6 border-t border-gray-100 flex justify-end gap-4 bg-gray-50 rounded-b-3xl">
             <button onClick={onClose} className="px-6 py-3 rounded-xl font-bold text-gray-500 hover:bg-gray-200 transition-colors">
               关闭
             </button>
             <button 
               onClick={handleCopy}
               className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center gap-2"
             >
               {copied ? <CheckIcon className="w-4 h-4" /> : <CopyIcon className="w-4 h-4" />}
               {copied ? "已复制" : "复制报告"}
             </button>
          </div>
       </div>
    </div>
  );
};

// --- Main App Component ---

const App = () => {
  // Navigation State
  const [view, setView] = useState<'home' | 'recommend' | 'select' | 'editor'>('home');
  
  // Data State
  const [history, setHistory] = useState<ReviewEntry[]>([]);
  const [userContext, setUserContext] = useState('');
  const [recommendation, setRecommendation] = useState<RecommendationResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Selection & Reports State
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [generatedReport, setGeneratedReport] = useState<string | null>(null);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  
  // Editor State
  const [activeMethod, setActiveMethod] = useState<ReviewMethodType>(ReviewMethodType.KISS);
  const [editorTitle, setEditorTitle] = useState('');
  const [kissData, setKissData] = useState<KissData>(initialKiss);
  const [graiData, setGraiData] = useState<GraiData>(initialGrai);
  const [deepData, setDeepData] = useState<DeepDiveData>(initialDeep);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Load History
  useEffect(() => {
    const saved = localStorage.getItem('review_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse history");
      }
    }
  }, []);

  // Save History Helper
  const saveToHistory = (newEntry: ReviewEntry) => {
    const newHistory = [newEntry, ...history.filter(h => h.id !== newEntry.id)];
    setHistory(newHistory);
    localStorage.setItem('review_history', JSON.stringify(newHistory));
  };

  const deleteHistoryItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if(confirm('确定要删除这条复盘记录吗？')) {
      const newHistory = history.filter(h => h.id !== id);
      setHistory(newHistory);
      localStorage.setItem('review_history', JSON.stringify(newHistory));
      if (editingId === id) setView('home');
      // Also remove from selection
      if (selectedIds.includes(id)) {
        setSelectedIds(selectedIds.filter(sid => sid !== id));
      }
    }
  };

  // --- Handlers ---

  const handleStartAnalysis = async () => {
    if (!userContext.trim()) return;
    setIsAnalyzing(true);
    try {
      const result = await getMethodRecommendation(userContext);
      setRecommendation(result);
      setView('select');
    } catch (e) {
      console.error(e);
      // Fallback if AI fails
      setRecommendation({
         recommendedMethod: ReviewMethodType.KISS,
         reason: "网络原因无法分析，建议使用通用的KISS复盘法。"
      });
      setView('select');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSelectMethod = (method: ReviewMethodType) => {
    setActiveMethod(method);
    // Reset data for new entry if we are not editing an existing one
    if (view === 'select' || view === 'recommend') {
      setKissData(initialKiss);
      setGraiData(initialGrai);
      setDeepData(initialDeep);
      setEditorTitle(format(new Date(), 'yyyy-MM-dd') + ' 复盘');
      setEditingId(null);
    }
    setView('editor');
  };

  const handleSave = () => {
    if (!editorTitle.trim()) {
      alert("请输入标题");
      return;
    }

    let contentPayload: any;
    if (activeMethod === ReviewMethodType.KISS) contentPayload = kissData;
    else if (activeMethod === ReviewMethodType.GRAI) contentPayload = graiData;
    else contentPayload = deepData;

    const entry: ReviewEntry = {
      id: editingId || Date.now().toString(),
      date: editingId ? (history.find(h => h.id === editingId)?.date || Date.now()) : Date.now(),
      title: editorTitle,
      method: activeMethod,
      content: contentPayload,
    };

    saveToHistory(entry);
    setEditingId(null);
    setView('home'); 
  };

  const openHistoryItem = (item: ReviewEntry) => {
    setEditingId(item.id);
    setEditorTitle(item.title);
    setActiveMethod(item.method);
    
    if (item.method === ReviewMethodType.KISS) setKissData(item.content as KissData);
    else if (item.method === ReviewMethodType.GRAI) setGraiData(item.content as GraiData);
    else if (item.method === ReviewMethodType.DEEP_DIVE) setDeepData(item.content as DeepDiveData);
    
    setView('editor');
  };
  
  const handleReset = () => {
    setEditingId(null);
    setUserContext('');
    setRecommendation(null);
    setView('recommend');
    setSelectedIds([]);
  }

  // --- Multi-Select & Report Handlers ---

  const toggleSelection = (id: string) => {
    if (id === 'CLEAR_ALL') {
      setSelectedIds([]);
      return;
    }
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(sid => sid !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const generateReportHandler = async (type: ReportType) => {
    if (selectedIds.length === 0) return;
    setIsGeneratingReport(true);
    
    const selectedReviews = history.filter(h => selectedIds.includes(h.id));
    
    try {
      const report = await generateReport(selectedReviews, type);
      setGeneratedReport(report);
    } catch (e) {
      console.error(e);
      alert("生成报告失败，请重试。");
    } finally {
      setIsGeneratingReport(false);
    }
  };

  // --- Main Layout ---

  return (
    <div className="flex h-screen bg-[#F8FAFC] overflow-hidden">
       {/* Global Overlay Loading for Report Generation */}
       {isGeneratingReport && (
          <div className="fixed inset-0 bg-black/50 z-[100] flex flex-col items-center justify-center backdrop-blur-sm text-white">
             <div className="w-16 h-16 border-4 border-indigo-500 border-t-white rounded-full animate-spin mb-4"></div>
             <p className="font-bold text-lg animate-pulse">正在生成智能报告...</p>
             <p className="text-sm opacity-70">Gemini 正在分析您的复盘记录</p>
          </div>
       )}

       {/* Report Modal */}
       {generatedReport && (
          <ReportModal content={generatedReport} onClose={() => setGeneratedReport(null)} />
       )}

       <Sidebar 
          view={view} 
          setView={setView} 
          history={history} 
          onDeleteHistory={deleteHistoryItem} 
          onOpenHistory={openHistoryItem}
          onReset={handleReset}
       />
       <main className="flex-1 overflow-y-auto custom-scrollbar relative">
          <div className="p-8 min-h-full flex flex-col">
            {view === 'home' && (
              <HomeView 
                history={history} 
                setView={setView} 
                onOpenHistory={openHistoryItem}
                selectedIds={selectedIds}
                toggleSelection={toggleSelection}
                generateReportHandler={generateReportHandler}
              />
            )}
            {view === 'recommend' && (
              <RecommendView 
                userContext={userContext} 
                setUserContext={setUserContext} 
                isAnalyzing={isAnalyzing} 
                handleStartAnalysis={handleStartAnalysis} 
                setView={setView} 
              />
            )}
            {view === 'select' && (
              <SelectView 
                setView={setView} 
                recommendation={recommendation} 
                handleSelectMethod={handleSelectMethod} 
              />
            )}
            {view === 'editor' && (
              <EditorView 
                setView={setView}
                editorTitle={editorTitle}
                setEditorTitle={setEditorTitle}
                handleSave={handleSave}
                activeMethod={activeMethod}
                kissData={kissData}
                setKissData={setKissData}
                graiData={graiData}
                setGraiData={setGraiData}
                deepData={deepData}
                setDeepData={setDeepData}
              />
            )}
          </div>
       </main>
    </div>
  );
};

export default App;
