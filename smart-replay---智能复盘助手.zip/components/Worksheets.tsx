
import React, { useState, useRef, useEffect } from 'react';
import { KissData, GraiData, DeepDiveData } from '../types';
import { SparklesIcon, MagicWandIcon, LoadingIcon, PlusIcon } from './Icons';
import { refineText, RefineAction } from '../services/geminiService';

// --- AI Smart Textarea Component ---
const SmartTextarea = ({ 
  value, 
  onChange, 
  placeholder, 
  label, 
  colorClass = "bg-white",
  borderColor = "border-gray-200",
  tips
}: { 
  value: string; 
  onChange: (val: string) => void; 
  placeholder: string; 
  label: string; 
  colorClass?: string;
  borderColor?: string;
  tips?: { title: string, content: string }
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isTipOpen, setIsTipOpen] = useState(false);
  const [isRefining, setIsRefining] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const tipRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
      if (tipRef.current && !tipRef.current.contains(event.target as Node)) {
        setIsTipOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleAIAction = async (action: RefineAction) => {
    setIsMenuOpen(false);
    setIsRefining(true);
    try {
      const result = await refineText(value, action, label);
      onChange(result);
    } catch (e) {
      console.error(e);
    } finally {
      setIsRefining(false);
    }
  };

  return (
    <div className="relative group h-full flex flex-col">
      <div className="flex-1 relative">
        <textarea
          className={`w-full h-full ${colorClass} border-2 ${borderColor} rounded-xl p-4 pr-12 focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-indigo-500 resize-none transition-all text-gray-900 placeholder-gray-400 leading-relaxed custom-scrollbar text-sm shadow-sm`}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={isRefining}
        />
        
        {/* Loading Overlay */}
        {isRefining && (
          <div className="absolute inset-0 bg-white/60 backdrop-blur-[1px] rounded-xl flex items-center justify-center z-10">
            <div className="flex items-center gap-2 text-indigo-600 font-bold bg-white px-4 py-2 rounded-full shadow-lg">
              <LoadingIcon className="w-4 h-4 animate-spin" />
              AI 思考中...
            </div>
          </div>
        )}

        {/* Action Buttons Container */}
        <div className="absolute bottom-3 right-3 flex flex-col gap-2 z-10">
            
            {/* Tips Trigger */}
            {tips && (
              <div className="relative" ref={tipRef}>
                <button
                  onClick={() => setIsTipOpen(!isTipOpen)}
                  className="p-2 rounded-full shadow-sm bg-white/90 text-yellow-500 hover:bg-yellow-50 hover:scale-110 transition-all border border-gray-100 flex items-center justify-center"
                  title="查看示例"
                >
                  <span className="text-sm font-bold">💡</span>
                </button>
                {isTipOpen && (
                   <div className="absolute bottom-0 right-10 mb-0 w-64 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden animate-in origin-bottom-right p-4 z-20">
                      <h5 className="font-bold text-gray-800 text-sm mb-1">{tips.title}</h5>
                      <p className="text-xs text-gray-500 leading-relaxed">{tips.content}</p>
                   </div>
                )}
              </div>
            )}

            {/* AI Trigger */}
            <div className={`transition-all duration-200 ${value.length > 0 ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
              <div className="relative" ref={menuRef}>
                  <button 
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                    className={`p-2 rounded-full shadow-sm backdrop-blur-md border border-white/50 transition-all flex items-center justify-center
                      ${isMenuOpen ? 'bg-indigo-600 text-white rotate-12 scale-110' : 'bg-white/90 text-indigo-500 hover:bg-indigo-50 hover:scale-110'}`}
                    title="AI 辅助"
                  >
                    <MagicWandIcon className="w-4 h-4" />
                  </button>

                  {/* AI Menu */}
                  {isMenuOpen && (
                    <div className="absolute bottom-full right-0 mb-2 w-32 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden animate-in origin-bottom-right">
                      <div className="px-3 py-2 text-[10px] font-bold text-gray-400 uppercase tracking-wider bg-gray-50 border-b border-gray-100">AI 助手</div>
                      <button onClick={() => handleAIAction(RefineAction.EXPAND)} className="w-full text-left px-3 py-2 text-xs hover:bg-indigo-50 text-gray-700 flex items-center gap-2">
                        <span className="text-lg">📝</span> 帮我扩写
                      </button>
                      <button onClick={() => handleAIAction(RefineAction.POLISH)} className="w-full text-left px-3 py-2 text-xs hover:bg-indigo-50 text-gray-700 flex items-center gap-2">
                        <span className="text-lg">✨</span> 润色文字
                      </button>
                      <button onClick={() => handleAIAction(RefineAction.SUMMARIZE)} className="w-full text-left px-3 py-2 text-xs hover:bg-indigo-50 text-gray-700 flex items-center gap-2">
                        <span className="text-lg">💡</span> 提炼重点
                      </button>
                      <button onClick={() => handleAIAction(RefineAction.ACTION_ITEMS)} className="w-full text-left px-3 py-2 text-xs hover:bg-indigo-50 text-gray-700 flex items-center gap-2">
                        <span className="text-lg">🚀</span> 生成行动
                      </button>
                    </div>
                  )}
              </div>
            </div>
        </div>

      </div>
    </div>
  );
};

// --- 1. KISS Editor (Grid Layout) ---
export const KissEditor = ({ data, onChange }: { data: KissData, onChange: (d: KissData) => void }) => {
  const update = (key: keyof KissData, val: string) => onChange({ ...data, [key]: val });

  return (
    <div className="w-full h-full bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden flex flex-col">
      {/* Header matching the card */}
      <div className="bg-[#f0f4f8] p-6 border-b border-dashed border-gray-300">
        <div className="flex justify-between items-center mb-4">
          <div className="bg-indigo-600 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg shadow-indigo-200">KISS 复盘法</div>
          <div className="text-gray-400 text-xs font-mono">STEP 1-4 GUIDE</div>
        </div>
        <div className="grid grid-cols-4 gap-4 text-xs text-gray-500">
          <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-lime-500"></span> review回顾</div>
          <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-sky-500"></span> analyze分析</div>
          <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500"></span> extract萃取</div>
          <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-rose-500"></span> apply应用</div>
        </div>
      </div>

      {/* Main Content - Quadrants */}
      <div className="flex-1 p-6 grid grid-cols-2 grid-rows-2 gap-6 bg-[#fdfdfd]">
        {/* Keep */}
        <div className="flex flex-col h-full">
           <div className="flex items-center gap-2 mb-2">
              <div className="bg-lime-500 text-white p-1.5 rounded-lg shadow-md shadow-lime-200">
                <PlusIcon className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-black text-lime-600 text-lg leading-none">Keep</h4>
                <span className="text-xs text-gray-400 font-bold">保持</span>
              </div>
           </div>
           <div className="flex-1">
             <SmartTextarea 
                value={data.keep} 
                onChange={(v) => update('keep', v)} 
                placeholder="哪些做得好，需要继续保持？"
                label="Keep/保持"
                colorClass="bg-lime-50"
                borderColor="border-lime-200"
                tips={{ title: "💡 示例", content: "如：每日站会大家都很准时，信息同步效率高；新上线的自动化测试脚本节省了20%的回归时间。" }}
             />
           </div>
        </div>

        {/* Improve */}
        <div className="flex flex-col h-full">
           <div className="flex items-center gap-2 mb-2">
              <div className="bg-sky-500 text-white p-1.5 rounded-lg shadow-md shadow-sky-200">
                <SparklesIcon className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-black text-sky-600 text-lg leading-none">Improve</h4>
                <span className="text-xs text-gray-400 font-bold">改进</span>
              </div>
           </div>
           <div className="flex-1">
             <SmartTextarea 
                value={data.improve} 
                onChange={(v) => update('improve', v)} 
                placeholder="哪些做得不够，需要改进？"
                label="Improve/改进"
                colorClass="bg-sky-50"
                borderColor="border-sky-200"
                tips={{ title: "💡 示例", content: "如：需求文档细节不够清晰，导致开发返工；跨部门沟通响应时间过长。" }}
             />
           </div>
        </div>

        {/* Stop */}
        <div className="flex flex-col h-full">
           <div className="flex items-center gap-2 mb-2">
              <div className="bg-amber-500 text-white p-1.5 rounded-lg shadow-md shadow-amber-200">
                <span className="font-black text-xs">STOP</span>
              </div>
              <div>
                <h4 className="font-black text-amber-600 text-lg leading-none">Stop</h4>
                <span className="text-xs text-gray-400 font-bold">停止</span>
              </div>
           </div>
           <div className="flex-1">
             <SmartTextarea 
                value={data.stop} 
                onChange={(v) => update('stop', v)} 
                placeholder="哪些行为是无益的，应该停止？"
                label="Stop/停止"
                colorClass="bg-amber-50"
                borderColor="border-amber-200"
                tips={{ title: "💡 示例", content: "如：停止在没有议程的情况下开会；停止手动部署代码，改为CI/CD。" }}
             />
           </div>
        </div>

        {/* Start */}
        <div className="flex flex-col h-full">
           <div className="flex items-center gap-2 mb-2">
              <div className="bg-rose-500 text-white p-1.5 rounded-lg shadow-md shadow-rose-200">
                <span className="font-black text-xs">GO</span>
              </div>
              <div>
                <h4 className="font-black text-rose-600 text-lg leading-none">Start</h4>
                <span className="text-xs text-gray-400 font-bold">开始</span>
              </div>
           </div>
           <div className="flex-1">
             <SmartTextarea 
                value={data.start} 
                onChange={(v) => update('start', v)} 
                placeholder="哪些新行动需要开始执行？"
                label="Start/开始"
                colorClass="bg-rose-50"
                borderColor="border-rose-200"
                tips={{ title: "💡 示例", content: "如：开始实施代码审查机制；每周五下午进行技术分享会。" }}
             />
           </div>
        </div>
      </div>
    </div>
  );
};

// --- Grai Section Component (Extracted) ---
const GraiSection = ({ title, sub, color, border, bg, value, onChange, field, placeholder, icon, tipContent }: any) => (
  <div className={`flex gap-4 p-4 rounded-2xl ${bg} border ${border} transition-all hover:shadow-md group`}>
    <div className={`w-12 flex flex-col items-center pt-2`}>
      <div className={`w-10 h-10 rounded-xl ${color} text-white flex items-center justify-center shadow-lg font-bold text-lg mb-2`}>
        {icon}
      </div>
      <div className={`w-0.5 flex-1 ${border} bg-opacity-50 dashed group-last:hidden`}></div>
    </div>
    <div className="flex-1 pb-4">
      <div className="mb-2">
        <h4 className="font-black text-gray-800 text-lg">{title}</h4>
        <p className="text-xs text-gray-500 font-medium">{sub}</p>
      </div>
      <div className="h-32">
        <SmartTextarea 
          value={value} 
          onChange={(v) => onChange(field, v)} 
          placeholder={placeholder}
          label={`${title} ${sub}`}
          colorClass="bg-white" 
          borderColor="border-white"
          tips={{ title: `${title} 指南`, content: tipContent }}
        />
      </div>
    </div>
  </div>
);

// --- 2. GRAI Editor (Vertical Process Flow) ---
export const GraiEditor = ({ data, onChange }: { data: GraiData, onChange: (d: GraiData) => void }) => {
  const update = (key: keyof GraiData, val: string) => onChange({ ...data, [key]: val });

  return (
    <div className="w-full h-full bg-white rounded-3xl shadow-sm border border-gray-200 overflow-y-auto custom-scrollbar">
       <div className="p-8 pb-4">
          <div className="flex items-center gap-3 mb-6">
             <div className="w-12 h-12 bg-sky-500 rounded-2xl rotate-3 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-sky-200">G</div>
             <div>
               <h3 className="text-2xl font-black text-gray-800">GRAI 复盘法</h3>
               <p className="text-sm text-gray-400">Goal • Result • Analysis • Insight</p>
             </div>
          </div>
       </div>

       <div className="px-8 pb-8 space-y-4">
          <GraiSection 
            title="Goal" sub="回顾目标" 
            color="bg-sky-500" border="border-sky-200" bg="bg-sky-50"
            value={data.goal} onChange={update} field="goal" icon="G"
            placeholder="当初设定的目标是什么？里程碑有哪些？"
            tipContent="目标必须清晰可衡量。如：在Q1结束前，用户留存率提升至45%。"
          />
          <GraiSection 
            title="Result" sub="评估结果" 
            color="bg-blue-500" border="border-blue-200" bg="bg-blue-50"
            value={data.result} onChange={update} field="result" icon="R"
            placeholder="实际发生了什么？与目标的差距是多少？"
            tipContent="客观陈述事实，不带感情色彩。如：实际留存率仅为38%，比目标低7个百分点。"
          />
          <GraiSection 
            title="Analysis" sub="分析原因" 
            color="bg-indigo-500" border="border-indigo-200" bg="bg-indigo-50"
            value={data.analysis} onChange={update} field="analysis" icon="A"
            placeholder="为什么会发生这些差距？主观/客观原因是什么？"
            tipContent="区分主观原因（如策略失误）和客观原因（如市场波动）。多问几个'为什么'。"
          />
          <GraiSection 
            title="Insight" sub="总结规律" 
            color="bg-violet-500" border="border-violet-200" bg="bg-violet-50"
            value={data.insight} onChange={update} field="insight" icon="I"
            placeholder="我们学到了什么？接下来的行动计划是什么？"
            tipContent="提炼出可复制的经验或需规避的坑。如：推送时间对留存影响巨大，需建立最佳推送时刻表。"
          />
       </div>
    </div>
  );
};

// --- DeepDive Step Component (Extracted) ---
const DeepDiveStep = ({ num, title, desc, color, value, onChange, field, placeholder, tipContent }: any) => (
  <div className="relative pl-8 pb-8 last:pb-0">
     {/* Timeline Line */}
     <div className="absolute left-3 top-8 bottom-0 w-0.5 bg-gray-200 last:hidden"></div>
     
     <div className="flex items-start gap-4">
        {/* Number Bubble */}
        <div className={`absolute left-0 w-6 h-6 rounded-full ${color} text-white flex items-center justify-center text-xs font-bold ring-4 ring-white`}>
          {num}
        </div>
        
        <div className="flex-1 bg-gray-50 rounded-2xl p-5 border border-gray-100 hover:border-gray-300 transition-colors">
           <div className="flex justify-between items-start mb-3">
             <div>
                <h4 className="font-bold text-gray-800">{title}</h4>
                <p className="text-xs text-gray-400 mt-0.5">{desc}</p>
             </div>
           </div>
           <div className="h-28">
             <SmartTextarea 
                value={value} 
                onChange={(v) => onChange(field, v)} 
                placeholder={placeholder}
                label={title}
                colorClass="bg-white"
                borderColor="border-gray-200"
                tips={{ title: "💡 深度引导", content: tipContent }}
             />
           </div>
        </div>
     </div>
  </div>
);

// --- 3. Deep Dive Editor (Step-by-Step Blueprint) ---
export const DeepDiveEditor = ({ data, onChange }: { data: DeepDiveData, onChange: (d: DeepDiveData) => void }) => {
  const update = (key: keyof DeepDiveData, val: string) => onChange({ ...data, [key]: val });

  return (
    <div className="w-full h-full bg-white rounded-3xl shadow-sm border border-gray-200 overflow-y-auto custom-scrollbar flex flex-col">
       <div className="bg-indigo-900 p-8 text-white relative overflow-hidden shrink-0">
          <div className="relative z-10">
             <h3 className="text-2xl font-black mb-1">Deep Dive</h3>
             <p className="text-indigo-200 text-sm">深度复盘 • 根因分析 • 经验萃取</p>
          </div>
          {/* Decorative Pattern */}
          <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
       </div>

       <div className="p-8 flex-1">
          <DeepDiveStep 
            num="1" title="回顾目标" desc="Review Goal" color="bg-indigo-600"
            value={data.step1_review} onChange={update} field="step1_review"
            placeholder="回顾最初的目的与期望，发生了什么？"
            tipContent="详细描述事件的起因、经过和结果。与预期相比，有哪些明显的偏差？"
          />
          <DeepDiveStep 
            num="2" title="评估结果" desc="Analyze Result" color="bg-indigo-600"
            value={data.step2_analyze} onChange={update} field="step2_analyze"
            placeholder="分析成功或失败的根本原因（5 Whys）。"
            tipContent="使用5Why法：为什么发生？->因为A。为什么A发生？->因为B... 直到找到根本原因。"
          />
          <DeepDiveStep 
            num="3" title="萃取经验" desc="Extract Wisdom" color="bg-indigo-600"
            value={data.step3_extract} onChange={update} field="step3_extract"
            placeholder="从中学到了什么规律？是否可以复制？"
            tipContent="如果重来一次，我们会怎么做？这个经验是否可以推广到其他项目？"
          />
          <DeepDiveStep 
            num="4" title="应用计划" desc="Action Plan" color="bg-indigo-600"
            value={data.step4_action} onChange={update} field="step4_action"
            placeholder="制定具体的下一步行动计划（Who, What, When）。"
            tipContent="具体的行动项（Action Items），明确负责人（Owner）和截止时间（Deadline）。"
          />
       </div>
    </div>
  );
};
